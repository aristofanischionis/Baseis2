#ifndef DEFN_H_
#define DEFN_H_

#define INTEGER 'i'
#define FLOAT 'f'
#define STRING 'c'

#endif /* DEFN_H_ */
